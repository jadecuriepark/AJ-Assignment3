
public abstract class Product {
	public abstract String outputProduct();
}
